GOAT Trading Mobile — pachet PWA static
Pentru instalare ca aplicație pe iPhone, publică folderul public pe o gazdă HTTPS (de exemplu GitHub Pages), apoi deschide adresa în Safari > Share > Add to Home Screen.
Graficul TradingView necesită internet și poate avea întârziere/licențiere diferită față de cotația Pepperstone.
Soldul, P/L și pozițiile sunt introduse manual. Nu există conexiune directă la MT5 iPhone și nu execută ordine.
Jurnalul și calculatorul sunt locale pe dispozitiv.
